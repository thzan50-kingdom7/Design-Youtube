package com.example.youtubedemo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Red = Color(0xFFFF0033)
private val videos = listOf(
 Video(1,"Học Kotlin trong 15 phút - dành cho người mới","Code Cùng Bạn","125 N lượt xem","2 ngày trước","15:24","Giới thiệu Kotlin, biến, hàm và cách xây dựng ứng dụng Android.",Color(0xFF315B8A)),
 Video(2,"Khám phá thành phố về đêm | Cinematic 4K","Travel Việt Nam","82 N lượt xem","1 tuần trước","08:42","Một chuyến khám phá thành phố với góc quay điện ảnh.",Color(0xFF8C4A38)),
 Video(3,"Nhạc thư giãn học tập và làm việc","Daily Music","1,2 Tr lượt xem","3 tuần trước","32:10","Nhạc nhẹ nhàng giúp tập trung học tập và làm việc.",Color(0xFF547A61)),
 Video(4,"Thiết kế giao diện Android bằng Compose","Android Lab","54 N lượt xem","5 ngày trước","21:05","Thực hành tạo giao diện với Jetpack Compose.",Color(0xFF76518C)),
 Video(5,"10 mẹo học tập hiệu quả cho sinh viên","Study Better","210 N lượt xem","1 tháng trước","11:18","Phương pháp sắp xếp thời gian và học tập hiệu quả.",Color(0xFF9A783A))
)
data class Video(val id:Int,val title:String,val channel:String,val views:String,val age:String,val duration:String,val description:String,val color:Color)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { YouTubeApp() }}
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun YouTubeApp(){
 var tab by remember { mutableStateOf("Trang chủ") }
 var opened by remember { mutableStateOf<Video?>(null) }
 var query by remember { mutableStateOf("") }
 val liked= remember { mutableStateListOf<Int>() }
 val subs= remember { mutableStateListOf<String>() }
 val comments= remember { mutableStateMapOf<Int,MutableList<String>>() }
 MaterialTheme(colorScheme=lightColorScheme(primary=Red,background=Color(0xFFF8F8F8))){
  Scaffold(
   topBar={
    TopAppBar(
     title={ if(opened==null) Row(verticalAlignment=Alignment.CenterVertically){Text("▶",color=Red,fontSize=23.sp);Spacer(Modifier.width(6.dp));Text("YouTube",fontWeight=FontWeight.Bold);Text("  DEMO",fontSize=10.sp,color=Color.Gray)} else Text("Đang xem video") },
     navigationIcon={if(opened!=null) IconButton(onClick={opened=null}){Icon(Icons.Default.ArrowBack,"Quay lại")}},
     actions={if(opened==null){IconButton(onClick={tab="Tìm kiếm"}){Icon(Icons.Default.Search,"Tìm kiếm")};IconButton(onClick={tab="Cá nhân"}){Icon(Icons.Default.AccountCircle,"Tài khoản")}}
     },colors=TopAppBarDefaults.topAppBarColors(containerColor=Color.White))
   },
   bottomBar={if(opened==null) NavigationBar(containerColor=Color.White){
    listOf("Trang chủ","Shorts","Đăng ký","Cá nhân").forEach { name ->
     val icon=when(name){"Trang chủ"->Icons.Default.Home;"Shorts"->Icons.Default.PlayCircle;"Đăng ký"->Icons.Default.Subscriptions;else->Icons.Default.Person}
     NavigationBarItem(selected=tab==name,onClick={tab=name},icon={Icon(icon,name)},label={Text(name,fontSize=10.sp)})
    }
   }},
   containerColor=Color(0xFFF8F8F8)
  ){ padding ->
   if(opened!=null){
    val v=opened!!
    Detail(v,liked.contains(v.id),subs.contains(v.channel),comments[v.id]?: emptyList(),
     {if(liked.contains(v.id))liked.remove(v.id) else liked.add(v.id)},
     {if(subs.contains(v.channel))subs.remove(v.channel) else subs.add(v.channel)},
     {msg->val list=comments[v.id]?: mutableListOf<String>().also{comments[v.id]=it};list.add(0,msg)},
     {opened=it},Modifier.padding(padding))
   }else when(tab){
    "Tìm kiếm"->SearchPage(query,{query=it},{opened=it},Modifier.padding(padding))
    "Đăng ký"->Subscriptions(subs.toList(),{opened=it},Modifier.padding(padding))
    "Cá nhân"->Profile(liked.size,subs.size,Modifier.padding(padding))
    "Shorts"->Shorts(Modifier.padding(padding))
    else->Home({opened=it},Modifier.padding(padding))
   }
  }
 }
}

@Composable fun Home(onOpen:(Video)->Unit,modifier:Modifier=Modifier){
 LazyColumn(modifier.fillMaxSize()){
  item{Row(Modifier.fillMaxWidth().background(Color.White).padding(10.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("Tất cả","Âm nhạc","Trò chơi","Học tập").forEachIndexed{i,s->Surface(color=if(i==0)Color.Black else Color(0xFFECECEC),shape=RoundedCornerShape(8.dp)){Text(s,color=if(i==0)Color.White else Color.Black,modifier=Modifier.padding(10.dp),fontSize=12.sp)}}}}
  items(videos){VideoItem(it){onOpen(it)}}
 }
}
@Composable fun VideoItem(v:Video,onClick:()->Unit){
 Column(Modifier.fillMaxWidth().background(Color.White).clickable{onClick()}.padding(bottom=12.dp)){
  Box(Modifier.fillMaxWidth().height(195.dp).background(v.color),contentAlignment=Alignment.Center){
   Text("▶",fontSize=55.sp,color=Color.White)
   Text("DEMO  •  ${v.duration}",color=Color.White,fontSize=11.sp,modifier=Modifier.align(Alignment.BottomEnd).padding(9.dp).background(Color.Black.copy(alpha=.7f)).padding(5.dp))
  }
  Row(Modifier.padding(horizontal=12.dp,vertical=10.dp),verticalAlignment=Alignment.Top){
   Box(Modifier.size(38.dp).background(v.color,CircleShape),contentAlignment=Alignment.Center){Text(v.channel.take(1),color=Color.White,fontWeight=FontWeight.Bold)}
   Spacer(Modifier.width(10.dp))
   Column(Modifier.weight(1f)){Text(v.title,fontWeight=FontWeight.SemiBold,fontSize=14.sp,maxLines=2,overflow=TextOverflow.Ellipsis);Text("${v.channel} • ${v.views} • ${v.age}",fontSize=11.sp,color=Color.Gray)}
   Icon(Icons.Default.MoreVert,null,tint=Color.Gray)
  }
 }
}
@Composable fun SearchPage(query:String,onQuery:(String)->Unit,onOpen:(Video)->Unit,modifier:Modifier=Modifier){
 Column(modifier.fillMaxSize()){
  OutlinedTextField(query,onQuery,Modifier.fillMaxWidth().padding(12.dp),placeholder={Text("Tìm video hoặc kênh")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true)
  val result=videos.filter{it.title.contains(query,true)||it.channel.contains(query,true)}
  if(result.isEmpty())Text("Không tìm thấy video.",Modifier.padding(20.dp),color=Color.Gray)
  else LazyColumn{items(result){VideoItem(it){onOpen(it)}}}
 }
}
@Composable fun Detail(v:Video,liked:Boolean,subscribed:Boolean,comments:List<String>,onLike:()->Unit,onSub:()->Unit,onComment:(String)->Unit,onOpen:(Video)->Unit,modifier:Modifier=Modifier){
 var playing by remember(v.id){mutableStateOf(false)}
 var progress by remember(v.id){mutableFloatStateOf(0f)}
 var input by remember(v.id){mutableStateOf("")}
 LaunchedEffect(playing){while(playing&&progress<1f){delay(500);progress=(progress+.015f).coerceAtMost(1f)};if(progress>=1f)playing=false}
 LazyColumn(modifier.fillMaxSize().background(Color.White)){
  item{
   Box(Modifier.fillMaxWidth().height(225.dp).background(Color(0xFF202020)),contentAlignment=Alignment.Center){
    IconButton(onClick={playing=!playing},modifier=Modifier.size(72.dp).background(Color.DarkGray,CircleShape)){Icon(if(playing)Icons.Default.Pause else Icons.Default.PlayArrow,null,tint=Color.White,modifier=Modifier.size(42.dp))}
    Text(if(playing)"ĐANG PHÁT DEMO" else "VIDEO DEMO",color=Color.White,fontSize=11.sp,modifier=Modifier.align(Alignment.TopStart).padding(12.dp))
    Column(Modifier.align(Alignment.BottomCenter).padding(horizontal=12.dp)){
     Slider(progress,{progress=it},colors=SliderDefaults.colors(thumbColor=Red,activeTrackColor=Red))
     Text("${(progress*100).toInt()}% • Trình phát mô phỏng",color=Color.White,fontSize=10.sp)
    }
   }
   Column(Modifier.padding(14.dp)){
    Text(v.title,fontSize=18.sp,fontWeight=FontWeight.Bold)
    Text("${v.views} • ${v.age}",color=Color.Gray,fontSize=12.sp)
    Spacer(Modifier.height(12.dp))
    Row(verticalAlignment=Alignment.CenterVertically){
     Box(Modifier.size(40.dp).background(v.color,CircleShape),contentAlignment=Alignment.Center){Text(v.channel.take(1),color=Color.White)}
     Spacer(Modifier.width(8.dp));Column(Modifier.weight(1f)){Text(v.channel,fontWeight=FontWeight.SemiBold);Text("Kênh YouTube • Demo",fontSize=11.sp,color=Color.Gray)}
     Button(onClick=onSub,colors=ButtonDefaults.buttonColors(containerColor=if(subscribed)Color.LightGray else Color.Black)){Text(if(subscribed)"Đã đăng ký" else "Đăng ký",color=if(subscribed)Color.Black else Color.White)}
    }
    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
     OutlinedButton(onClick=onLike){Icon(Icons.Default.ThumbUp,null);Spacer(Modifier.width(5.dp));Text(if(liked)"Đã thích" else "Thích")}
     OutlinedButton(onClick={playing=false;progress=0f}){Icon(Icons.Default.Refresh,null);Text("Phát lại")}
    }
    Surface(color=Color(0xFFF1F1F1),shape=RoundedCornerShape(12.dp)){Column(Modifier.fillMaxWidth().padding(12.dp)){Text("Mô tả",fontWeight=FontWeight.Bold);Text(v.description,fontSize=13.sp)}}
    Spacer(Modifier.height(14.dp));Text("Bình luận (${comments.size})",fontWeight=FontWeight.Bold)
    Row(verticalAlignment=Alignment.CenterVertically){
     OutlinedTextField(input,{input=it},Modifier.weight(1f),placeholder={Text("Viết bình luận...")},singleLine=true)
     IconButton(onClick={if(input.isNotBlank()){onComment(input.trim());input=""}}){Icon(Icons.Default.Send,null,tint=Red)}
    }
    comments.forEach{Text("●  $it",Modifier.padding(vertical=8.dp),fontSize=13.sp)}
    Text("Video đề xuất",fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp))
   }
  }
  items(videos.filter{it.id!=v.id}){VideoItem(it){onOpen(it)}}
 }
}
@Composable fun Subscriptions(channels:List<String>,onOpen:(Video)->Unit,modifier:Modifier=Modifier){
 val list=videos.filter{channels.contains(it.channel)}
 if(list.isEmpty())Column(modifier.fillMaxSize().background(Color.White).padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Icon(Icons.Default.Subscriptions,null,tint=Color.Gray,modifier=Modifier.size(50.dp));Text("Bạn chưa đăng ký kênh nào",fontWeight=FontWeight.Bold);Text("Mở video và nhấn Đăng ký để theo dõi.",color=Color.Gray,fontSize=12.sp)}
 else LazyColumn(modifier.fillMaxSize()){items(list){VideoItem(it){onOpen(it)}}}
}
@Composable fun Profile(likes:Int,subs:Int,modifier:Modifier=Modifier){
 Column(modifier.fillMaxSize().background(Color.White).padding(20.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.AccountCircle,null,modifier=Modifier.size(65.dp),tint=Color.DarkGray);Spacer(Modifier.width(12.dp));Column{Text("Người dùng Demo",fontWeight=FontWeight.Bold,fontSize=19.sp);Text("Tài khoản mô phỏng",color=Color.Gray,fontSize=12.sp)}}
  Spacer(Modifier.height(25.dp));Text("Thống kê hoạt động",fontWeight=FontWeight.Bold)
  Row(horizontalArrangement=Arrangement.spacedBy(12.dp)){Stat("Video đã thích",likes.toString(),Modifier.weight(1f));Stat("Kênh đăng ký",subs.toString(),Modifier.weight(1f))}
  Spacer(Modifier.height(22.dp));Text("Đề tài: Thiết kế hệ thống YouTube",fontWeight=FontWeight.SemiBold);Text("Kotlin • Android Studio • Jetpack Compose",fontSize=12.sp,color=Color.Gray)
 }
}
@Composable fun Stat(title:String,value:String,modifier:Modifier){Surface(modifier,color=Color(0xFFF1F1F1),shape=RoundedCornerShape(12.dp)){Column(Modifier.padding(14.dp)){Text(value,fontSize=24.sp,fontWeight=FontWeight.Bold,color=Red);Text(title,fontSize=12.sp)}}}
@Composable fun Shorts(modifier:Modifier=Modifier){
 var index by remember{mutableIntStateOf(0)};val v=videos[index%videos.size]
 Box(modifier.fillMaxSize().background(Color.Black)){
  Column(Modifier.align(Alignment.Center),horizontalAlignment=Alignment.CenterHorizontally){Text("▶",fontSize=80.sp,color=Color.White);Text("SHORTS DEMO",color=Color.White,fontWeight=FontWeight.Bold);Text(v.title,color=Color.White,modifier=Modifier.padding(20.dp))}
  Button(onClick={index++},modifier=Modifier.align(Alignment.BottomCenter).padding(24.dp)){Text("Video tiếp theo")}
 }
}
