# YouTube Kotlin Demo – Android Studio

Ứng dụng demo Android viết bằng Kotlin + Jetpack Compose.

## Chức năng
- Trang chủ: danh sách video mẫu.
- Tìm kiếm theo tiêu đề hoặc tên kênh.
- Màn hình xem video: nút phát/tạm dừng và thanh tiến trình mô phỏng.
- Thích/bỏ thích video.
- Đăng ký/bỏ đăng ký kênh.
- Viết bình luận trong phiên chạy.
- Shorts demo, trang cá nhân và thống kê.

## Yêu cầu
- Android Studio hỗ trợ Android Gradle Plugin 8.7.3.
- JDK 17 (chọn Embedded JDK 17 trong Android Studio).
- Android SDK Platform 35.
- Kết nối Internet lần đầu để Gradle tải thư viện.

## Mở và chạy
1. Giải nén ZIP.
2. Mở Android Studio > Open.
3. Chọn thư mục `YouTube_Kotlin_Demo` (chứa `settings.gradle.kts`).
4. Chờ Gradle Sync. Nếu hỏi JDK, chọn Embedded JDK 17.
5. Vào Tools > Device Manager, tạo máy ảo Pixel API 35/36, hoặc kết nối điện thoại bật USB debugging.
6. Chọn thiết bị ở thanh công cụ rồi nhấn Run ▶.

## Nếu Gradle Sync lỗi
- File > Settings > Build, Execution, Deployment > Build Tools > Gradle.
- Đặt Gradle JDK = Embedded JDK 17.
- Cài Android SDK Platform 35 trong SDK Manager.
- Chọn File > Sync Project with Gradle Files.
- Nếu Android Studio quá cũ, cập nhật Android Studio.

## Tạo APK để nộp
1. Build > Build Bundle(s) / APK(s) > Build APK(s).
2. Chờ thông báo APK(s) generated successfully.
3. Chọn Locate để mở thư mục APK.
4. APK debug thường ở `app/build/outputs/apk/debug/app-debug.apk`.

## Đóng gói source code
1. Đóng Android Studio.
2. Có thể xóa `.gradle`, `build`, `app/build` nếu có (không xóa `app/src`).
3. Giữ `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, thư mục `app`.
4. Nén thư mục `YouTube_Kotlin_Demo` thành ZIP.

## Giới hạn demo
Dữ liệu video là mẫu; màn hình player và thanh tiến trình được mô phỏng, chưa phát luồng video thật. Thích, đăng ký, bình luận chỉ giữ trong phiên chạy. Chưa có backend, tài khoản thật, database server hoặc CDN.
